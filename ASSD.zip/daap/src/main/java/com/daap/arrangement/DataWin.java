package com.daap.arrangement;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;

public class DataWin extends JFrame
{

	public DataWin()
	{
		try {
			for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		intiComponent();
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	private void intiComponent()
	{
		JTable table = new JTable(new TableData());
		DefaultTableCellRenderer r1 = new DefaultTableCellRenderer();
		r1.setHorizontalAlignment(JLabel.CENTER);
		table.setDefaultRenderer(Object.class, r1);
		JScrollPane scroll = new JScrollPane(table);
		add(scroll);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
	}



}