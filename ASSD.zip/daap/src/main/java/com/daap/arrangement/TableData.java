package com.daap.arrangement;

import com.daap.util.*;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;
public class TableData  extends AbstractTableModel{
		String[] columnNames = new String[Constants.SLIST.size()+1];
//				{ "ClassName", "MIM", "SFL" };//classname

		Object[][] data = new Object[Constants.HMAP.size()][columnNames.length];

		public TableData()
		{
			int xi=1;
			columnNames[0]="Class";
			for(String s:Constants.SLIST){
				columnNames[xi++]=s;
			}

			//设置ClassName
			Object sn[] =  Constants.HMAP.keySet().toArray();
			for(int i=0;i<getRowCount();i++){
				data[i][0]= sn[i];
			}
			//设置每种坏味道的次数
			for(int i=0;i<getRowCount();i++){
				for(int j=1;j<getColumnCount();j++) {
					if(Constants.HMAP.get((String) data[i][0]).containsKey(columnNames[j]))//存在当前坏味道
						data[i][j] = Constants.HMAP.get((String) data[i][0]).get(columnNames[j]).toString();
					else
						data[i][j] = 0;
				}
			}
		}
		@Override
		public String getColumnName(int column)
		{
			return columnNames[column];
		}

		@Override
		public int getColumnCount()
		{
			return columnNames.length;
		}

		@Override
		public int getRowCount()
		{
			return data.length;
		}

		@Override
		public Object getValueAt(int rowIndex, int columnIndex)
		{
			return data[rowIndex][columnIndex];
		}

		@Override
		public Class<?> getColumnClass(int columnIndex)
		{
			return data[0][columnIndex].getClass();
		}

		@Override
		public boolean isCellEditable(int rowIndex, int columnIndex)
		{
			if (columnIndex < 2)
				return false;
			else
				return true;
		}

		@Override
		public void setValueAt(Object aValue, int rowIndex, int columnIndex)
		{
			data[rowIndex][columnIndex] = aValue;
		}

}
