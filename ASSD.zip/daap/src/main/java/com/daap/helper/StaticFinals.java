package com.daap.helper;

/**
 * Created by AlI on 8/21/2017.
 */

public class StaticFinals {

    public static boolean isNullorEmpty(String s){
        return s == null || s.isEmpty();
    }

    public static boolean isChecked(int state){
        return state == 1;
    }
}
