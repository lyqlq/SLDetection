package com.daap.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class JOutputFilePicker extends JPanel {
    private JLabel label;
    private JTextField textField;
    private JButton button;

    private JFileChooser fileChooser;

    private final String defaultPath = "C:\\Users\\oxt\\save\\data\\output"; //
    private String path=defaultPath;
    public JOutputFilePicker(String textFieldLabel, String buttonLabel) {

        fileChooser = new JFileChooser(defaultPath);
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fileChooser.setAcceptAllFileFilterUsed(false);
        setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

        label = new JLabel(textFieldLabel);
        label.setFont(new Font("Courier New", Font.BOLD, 20));
        Action action = new Action();
        textField = new JTextField(22);
        textField.setSize(200, 50);
        textField.addActionListener(action);
        button = new JButton(buttonLabel);
        button.setSize(120, 50);
        button.addActionListener(evt -> buttonActionPerformed(evt));

        add(label);
        add(textField);
        add(button);

    }


    public void rest() {
        fileChooser.setCurrentDirectory(null);
        textField.setText("");
    }

    private void buttonActionPerformed(ActionEvent evt) {//1.brows button
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {//1.1
            String s = fileChooser.getSelectedFile().getAbsolutePath();
            textField.setText(s);
            path=s;
            System.out.println(s);
        }
    }

    public class Action implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String s;
            if (new File(s = textField.getText()).isDirectory()) {
                path=s;
            } else {
                JOptionPane.showMessageDialog(new JFrame(), "Path does not correspond to a folder!", "ERROR",
                        JOptionPane.ERROR_MESSAGE);
                        path=null;
            }
        }
    }


    public String getSelectedFilePath() {
        return textField.getText();
    }

    public JFileChooser getFileChooser() {
        return this.fileChooser;
    }

    public String getPath() {
        return path;
    }
}
