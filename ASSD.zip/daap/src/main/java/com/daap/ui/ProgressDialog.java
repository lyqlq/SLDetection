package com.daap.ui;

import java.awt.BorderLayout;
import java.awt.Window;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

/**
 * Created by ALI on 8/20/2017.
 */

public class ProgressDialog extends JDialog {

    private static  JDialog dialog;
    private static ProgressDialog progressDialog;



    public static ProgressDialog getInstance() {


        if (progressDialog == null){
            progressDialog = new ProgressDialog();
        }

        return progressDialog;
    }

    public void showDialog(Window win, String message) {

        if (dialog == null) {
            dialog = new JDialog(win, message, ModalityType.APPLICATION_MODAL);
            JProgressBar progressBar = new JProgressBar();
            progressBar.setIndeterminate(true);
            JPanel panel = new JPanel(new BorderLayout());
            panel.add(progressBar, BorderLayout.CENTER);
            panel.add(new JLabel("Please wait......."), BorderLayout.PAGE_START);
            dialog.add(panel);
            dialog.pack();
            dialog.dispose();
            dialog.setLocationRelativeTo(win);
            dialog.setVisible(true);

        }else{
            dialog.setVisible(true);
        }

    }

    public void cancel() {
        if (dialog != null) {
            try {
                dialog.setVisible(false);
                dialog = null;
            } catch (Exception e) {
                // nothing
                e.printStackTrace();
            }
        }
    }

}
