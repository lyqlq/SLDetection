package com.daap.ui;

import com.daap.engine.anti_patterns.mobile.*;
import com.daap.parse.MyDpvdVisitor;

import java.io.File;

/**
 * @author OXT
 * @version 2.0
 * @date 2021/10/13 17:59
 */
public class Test {
    @org.junit.Test
    public void testDetect(){
        String FolderPath="F:\\laboratory\\AndroidDatas\\Android-Image-Cropper-master";
        MyDpvdVisitor.listClasses(new File(FolderPath));//F:\laboratory\AndroidDates\a2dpvolume-master//F:\Idea_workspace\ASSD03\src\main\java\com\t
        LowMemoryDetectionEngine.detect();
        StaticViewDetectionEngine.detect();
        MIMDetectionEngine.detect();
        SlowForLoopDetectionEngine.detect();
        InternalSetGetDetectionEngine.detect();
    }
}
