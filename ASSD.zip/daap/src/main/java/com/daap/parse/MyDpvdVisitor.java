package com.daap.parse;

import com.daap.engine.anti_patterns.mobile.DroppedDataDetectionEngine;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.util.DirExplorer;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseProblemException;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//import com.github.javaparser.ast.Modifier;
//import com.github.javaparser.ast.body.ModifierSet;
//import com.google.common.base.Strings;

public class MyDpvdVisitor {

//    public static LegacyObject legacyObject = new LegacyObject();
//    public static SingletonData singletonData = new SingletonData();


//    public static LegacySystem legacySystem;
    @Test
    public void testDetect(){
        MyDpvdVisitor.listClasses(new File("F:\\laboratory\\AndroidDatas\\a2dpvolume-master"));//F:\laboratory\AndroidDates\a2dpvolume-master//F:\Idea_workspace\ASSD03\src\main\java\com\t
        DroppedDataDetectionEngine.detect();
    }
    public static void listClasses(File projectDir) {/*01假如projectDir="F:\laboratory\AndroidDates\a2dpvolume-master"*/

//        LegacySystem legacySystem = LegacySystem.getInstance();
//        legacySystem = new LegacySystem();
        //


        /*02DirExplorer(Filter filter, FileHandler fileHandler).explore(projectDir)*/
        new DirExplorer((level, path, file) -> path.endsWith(".java")/*//是否java后缀*/,
                (level, path, file) -> {
            /*/(level, path, file) -> path.endsWith(".java")相当于写一个接口实现//every .java??
            //file是选中的路径，通过递归分解找到java文件，path是最后java文件的路径*/
//            System.out.println(path);
//			  System.out.println(Strings.repeat("=", path.length()));
//            System.out.println("file: " + file.getName());

//            final ClassObject co = new ClassObject();
//            final LegacyClass legacyClass = new LegacyClass();
            try {//对java后缀的文件处理//file是选中的路径，通过递归分解找到java文件，path是最后java文件的路径
                new VoidVisitorAdapter<Object>() {
                    //重写visit
                    @Override
                    public void visit(ClassOrInterfaceDeclaration classDeclaration, Object javaParser/*null*/) {
                        super.visit(classDeclaration, javaParser);
                        /*发现它访问编译单元成员，需要调用相应子元素对应的Visitor类的visit（）方法*/
                        //javaParser对应VoidVisitorAdapter<Object>
                        //中的object
//                        classDeclaration.accept(new VoidVisitorAdapter<Object>() {
//                            @Override
//                            public void visit(VariableDeclarator variableDeclarationExpr, Object javaParserFacade) {
//                                super.visit(variableDeclarationExpr, javaParserFacade);
////                                System.out.println("classDeclaration: " + classDeclaration.getName() + " variableDeclarationExpr: " + variableDeclarationExpr.toString());
////                                System.out.println("classDeclaration: " + classDeclaration.getName() + " variableDeclarationExpr: " + variableDeclarationExpr.getType());
////                                System.out.println("classDeclaration: " + classDeclaration.getName() + " variableDeclarationExpr: " + variableDeclarationExpr.getAncestorOfType(ClassOrInterfaceDeclaration.class).get().getNameAsString());
//                            }
//                        }, null);


//                        System.out.println("classDeclaration: " + classDeclaration.getNameAsString() + " Inner: " + classDeclaration.isInnerClass());
//                        System.out.println("==================\n"+classDeclaration.getName());
                        addClass(classDeclaration, javaParser, path);

//                        if (classDeclaration.isInterface()) {
//                            LegacyClass legacyClass = new LegacyClass();
//                            legacyClass.setClassOrInterfaceDeclaration(classDeclaration);
//                            legacyClass.setName(classDeclaration.getName().toString());
//                            legacyClass.setFieldDeclarations(getFieldList(classDeclaration, classDeclaration.getName(), javaParser));
//                            legacyClass.setMethodDeclarations(getMethodsList(classDeclaration, classDeclaration.getName(), javaParser));
////                            System.out.println("Inner Class is interface: " + classDeclaration.getNameAsString());
//                            LegacySystem.getInstance().addClass(legacyClass);
//
//                        } else {
//
//
//                        }

//                        if (classDeclaration.isInnerClass() || (classDeclaration.isNestedType() && !classDeclaration.isInterface())) {
//                            if (classDeclaration.isInterface()) {
//                                legacyClass.getInnerInterfacesList().add(classDeclaration);
////                    legacyClass.getInnerInterfacesList().add(getClassOrInterfaceDeclaration(classDeclaration, javaParserFacade));
//                            } else {
////                                System.out.println("classDeclaration: "+classDeclaration.isStatic());
//                                legacyClass.getInnerClassesList().add(getClassOrInterfaceDeclaration(classDeclaration, javaParser));
//                            }
//
////                System.out.println("ClassOrInterfaceDeclaration isInnerClass getParentNode: " + classDeclaration.getParentNode().getClass().getName());
//                        } else {
//                            legacyClass.setClassOrInterfaceDeclaration(classDeclaration);
//                            legacyClass.setName(classDeclaration.getName().toString());
//                            legacyClass.setFieldDeclarations(getFieldList(classDeclaration, classDeclaration.getName(), javaParser));
//                            legacyClass.setVariableDeclarationExprs(getVariableList(classDeclaration, classDeclaration.getName(), javaParser));
//                            legacyClass.setMethodDeclarations(getMethodsList(classDeclaration, classDeclaration.getName(), javaParser));
//                            legacyClass.setMethodCallExprs(getMethodsCallList(classDeclaration, classDeclaration.getName(), javaParser));
//                            legacyClass.setObjectCreationExprs(getObjectCreationList(classDeclaration, classDeclaration.getName(), javaParser));
//                            legacyClass.setConstructorDeclarations(getConstructorList(classDeclaration, classDeclaration.getName(), javaParser));
//                        }
                    }
                }.visit(JavaParser.parse(file)/* 解析java文件 return CompilationUnit（编译单元） */, null);
//                System.out.println("legacyClass: "+legacyClass.getName());
//                LegacySystem.getInstance().addClass(legacyClass);
//                System.out.println("End Visiting File"); // empty line
            } catch (ParseProblemException | IOException e) {
//                System.out.println("in catch "+e.getMessage());
                new RuntimeException(e);
            }

        }).explore(projectDir);
//         System.out.println("after try catch");
//        return legacySystem;
    }

                        //addClass(classDeclaration, javaParser, path);
    private static void addClass(ClassOrInterfaceDeclaration classDeclaration, Object javaParser/*null*/, String path) {
        if (classDeclaration.isInterface()) {//interface
            LegacyClass legacyClass = new LegacyClass();//model
            legacyClass.setPath(path);//path
            legacyClass.setClassOrInterfaceDeclaration(classDeclaration);//整个添加进去
            legacyClass.setName(classDeclaration.getName().toString());//interface name
            legacyClass.setFieldDeclarations(getFieldList(classDeclaration, classDeclaration.getNameAsString(), javaParser));//fileDeclaration 属性声明
            legacyClass.setFieldAccessExprs((getFieldAccessExprList(classDeclaration, classDeclaration.getNameAsString(), javaParser)));//FieldAccessExpr 调用其他类的属性
            legacyClass.setMethodDeclarations(getMethodsList(classDeclaration, classDeclaration.getNameAsString(), javaParser/*null*/));
            LegacySystem.getInstance().addClass(legacyClass);
        } else {//class
            LegacyClass legacyClass = new LegacyClass();
            legacyClass.setPath(path);//path
            legacyClass.setClassOrInterfaceDeclaration(classDeclaration);//
            legacyClass.setName(classDeclaration.getName().toString());//class name
            legacyClass.setFieldDeclarations(getFieldList(classDeclaration, classDeclaration.getNameAsString(), javaParser));
            legacyClass.setFieldAccessExprs((getFieldAccessExprList(classDeclaration, classDeclaration.getNameAsString(), javaParser)));
            legacyClass.setVariableDeclarationExprs(getVariableList(classDeclaration, classDeclaration.getNameAsString(), javaParser));
            legacyClass.setVariableDeclarators((getVariableDeclarators(classDeclaration, classDeclaration.getNameAsString(), javaParser)));
            legacyClass.setMethodDeclarations(getMethodsList(classDeclaration, classDeclaration.getNameAsString(), javaParser));
            legacyClass.setMethodCallExprs(getMethodsCallList(classDeclaration, classDeclaration.getNameAsString(), javaParser));
            legacyClass.setObjectCreationExprs(getObjectCreationList(classDeclaration, classDeclaration.getNameAsString(), javaParser));
            legacyClass.setConstructorDeclarations(getConstructorList(classDeclaration, classDeclaration.getNameAsString(), javaParser));
            LegacySystem.getInstance().addClass(legacyClass);
        }
    }


//    private static LegacyClass getClassOrInterfaceDeclaration(ClassOrInterfaceDeclaration classDeclaration, Object javaParser) {
//        LegacyClass legacyClass = new LegacyClass();
//        legacyClass.setClassOrInterfaceDeclaration(classDeclaration);
//        legacyClass.setName(classDeclaration.getName().toString());
//        legacyClass.setFieldDeclarations(getFieldList(classDeclaration, classDeclaration.getName(), javaParser));
//        legacyClass.setVariableDeclarationExprs(getVariableList(classDeclaration, classDeclaration.getName(), javaParser));
//        legacyClass.setMethodDeclarations(getMethodsList(classDeclaration, classDeclaration.getName(), javaParser));
//        legacyClass.setMethodCallExprs(getMethodsCallList(classDeclaration, classDeclaration.getName(), javaParser));
//        legacyClass.setObjectCreationExprs(getObjectCreationList(classDeclaration, classDeclaration.getName(), javaParser));
//        legacyClass.setConstructorDeclarations(getConstructorList(classDeclaration, classDeclaration.getName(), javaParser));
//
//        return legacyClass;
//    }

    private static List<FieldDeclaration> getFieldList(ClassOrInterfaceDeclaration declaration, String simpleName, Object javaParserFacade) {
                                        //getFieldList(classDeclaration, classDeclaration.getNameAsString(), javaParser)
        List<FieldDeclaration> fieldDeclarations = new ArrayList<>();
//        System.out.println("\n-=-=fieldDeclarations-=-=");
        declaration.accept(new VoidVisitorAdapter<Object>() {
            @Override
            public void visit(FieldDeclaration fieldDeclaration, Object javaParserFacade) {
                super.visit(fieldDeclaration, javaParserFacade);
//                System.out.println("FieldDeclaration parent: " + fieldDeclaration.getAncestorOfType(ClassOrInterfaceDeclaration.class).get().getName() + " " + simpleName);
                if (fieldDeclaration.getAncestorOfType(ClassOrInterfaceDeclaration.class).get().getNameAsString().equals(simpleName.toString())) {
//                    System.out.println("FieldDeclaration parser: " + fieldDeclaration.toString());
                    fieldDeclarations.add(fieldDeclaration);
//                    System.out.println(fieldDeclaration.toString());
                }
            }
        }, javaParserFacade);
//        System.out.println("-=-=fieldDeclarations-end-=\n");
        return fieldDeclarations;
    }

    private static List<FieldAccessExpr> getFieldAccessExprList(ClassOrInterfaceDeclaration declaration, String simpleName, Object javaParserFacade) {
//        System.out.println("-=-=-=fieldAccessExprs-=-=");
        List<FieldAccessExpr> fieldAccessExprs = new ArrayList<>();
        declaration.accept(new VoidVisitorAdapter<Object>() {
            @Override
            public void visit(FieldAccessExpr fieldAccessExpr, Object javaParserFacade) {
                super.visit(fieldAccessExpr, javaParserFacade);
//                System.out.println("FieldDeclaration parent: " + fieldDeclaration.getAncestorOfType(ClassOrInterfaceDeclaration.class).get().getName() + " " + simpleName);
                if (fieldAccessExpr.getAncestorOfType(ClassOrInterfaceDeclaration.class).get().getNameAsString().equals(simpleName.toString())) {
//                    System.out.println("FieldDeclaration parser: " + fieldDeclaration.toString());
                    fieldAccessExprs.add(fieldAccessExpr);
//                    System.out.println(fieldAccessExpr.toString());
                }
            }
        }, javaParserFacade);
//        System.out.println("-=-=-=fieldAccessExprs-=-=end");
        return fieldAccessExprs;
    }

    private static List<VariableDeclarationExpr> getVariableList(ClassOrInterfaceDeclaration declaration, String simpleName, Object javaParserFacade) {

        List<VariableDeclarationExpr> variableDeclarationExprs = new ArrayList<>();
        declaration.accept(new VoidVisitorAdapter<Object>() {
            @Override
            public void visit(VariableDeclarationExpr variableDeclarationExpr, Object javaParserFacade) {
                super.visit(variableDeclarationExpr, javaParserFacade);
                if (variableDeclarationExpr.getAncestorOfType(ClassOrInterfaceDeclaration.class).get().getNameAsString().equals(simpleName)) {
                    variableDeclarationExprs.add(variableDeclarationExpr);
                }
            }
        }, javaParserFacade);
        return variableDeclarationExprs;
    }

    private static List<VariableDeclarator> getVariableDeclarators(ClassOrInterfaceDeclaration declaration, String simpleName, Object javaParserFacade) {

        List<VariableDeclarator> variableDeclarators = new ArrayList<>();
        declaration.accept(new VoidVisitorAdapter<Object>() {
            @Override
            public void visit(VariableDeclarator variableDeclarationExpr, Object javaParserFacade) {
                super.visit(variableDeclarationExpr, javaParserFacade);
                if (variableDeclarationExpr.getAncestorOfType(ClassOrInterfaceDeclaration.class).get().getNameAsString().equals(simpleName)) {
                    variableDeclarators.add(variableDeclarationExpr);
                }
            }
        }, javaParserFacade);
        return variableDeclarators;
    }

    private static List<ConstructorDeclaration> getConstructorList(ClassOrInterfaceDeclaration declaration, String simpleName, Object javaParserFacade) {
        List<ConstructorDeclaration> constructorDeclarations = new ArrayList<>();
        declaration.accept(new VoidVisitorAdapter<Object>() {
            @Override
            public void visit(ConstructorDeclaration constructorDeclaration, Object javaParserFacade) {
                super.visit(constructorDeclaration, javaParserFacade);
                if (constructorDeclaration.getAncestorOfType(ClassOrInterfaceDeclaration.class).get().getNameAsString().equals(simpleName)) {
                    constructorDeclarations.add(constructorDeclaration);
                }
            }
        }, javaParserFacade);

        return constructorDeclarations;
    }

    private static List<MethodDeclaration> getMethodsList(ClassOrInterfaceDeclaration declaration, String simpleName, Object javaParserFacade/*null*/) {
//        LegacyClass legacyClass= new LegacyClass();
//        legacyClass.setClassOrInterfaceDeclaration(declaration);//visit(JavaParser.parse(file)/* 解析java文件 return CompilationUnit（编译单元） */, null);
//                // JavaParser.parse(file)=declaration
        List<MethodDeclaration> methodDeclarations = new ArrayList<>();

        declaration.accept(new VoidVisitorAdapter<Object>() {
                    //相当于new VoidVisitorAdapter<Object>().visit(declaration,null)
            @Override
            public void visit(MethodDeclaration methodDeclaration/*JavaParser.parse(file)*/, Object javaParserFacade) {

                super.visit(methodDeclaration, javaParserFacade);
                if (methodDeclaration.getAncestorOfType(ClassOrInterfaceDeclaration.class)
                        .get().getNameAsString().equals(simpleName)) {
                    methodDeclarations.add(methodDeclaration);
                }
            }
        }, javaParserFacade/*null*/);

        return methodDeclarations;
    }

    private static List<MethodCallExpr> getMethodsCallList(ClassOrInterfaceDeclaration declaration, String simpleName, Object javaParserFacade) {
//        LegacyClass legacyClass= new LegacyClass();
//        legacyClass.setClassOrInterfaceDeclaration(declaration);
        List<MethodCallExpr> methodCallExprs = new ArrayList<>();
        declaration.accept(new VoidVisitorAdapter<Object>() {
            @Override
            public void visit(MethodCallExpr methodCallExpr, Object javaParserFacade) {
                super.visit(methodCallExpr, javaParserFacade);
//                if ()
                if (methodCallExpr.getAncestorOfType(ClassOrInterfaceDeclaration.class).get().getNameAsString().equals(simpleName)) {
                    methodCallExprs.add(methodCallExpr);
                }
            }
        }, javaParserFacade);

        return methodCallExprs;
    }

    private static List<ObjectCreationExpr> getObjectCreationList(ClassOrInterfaceDeclaration declaration, String simpleName, Object javaParserFacade) {
//        LegacyClass legacyClass= new LegacyClass();
//        legacyClass.setClassOrInterfaceDeclaration(declaration);
        List<ObjectCreationExpr> objectCreationExprs = new ArrayList<>();
        declaration.accept(new VoidVisitorAdapter<Object>() {
            @Override
            public void visit(ObjectCreationExpr objectCreationExpr, Object javaParserFacade) {
                super.visit(objectCreationExpr, javaParserFacade);
//                if ()
                if (objectCreationExpr.getAncestorOfType(ClassOrInterfaceDeclaration.class).get().getNameAsString().equals(simpleName)) {
                    objectCreationExprs.add(objectCreationExpr);
                }
            }
        }, javaParserFacade);

//        classDeclaration.accept(new VoidVisitorAdapter<Object>() {
//            @Override
//            public void visit(ObjectCreationExpr objectCreationExpr, Object javaParser) {
//                super.visit(objectCreationExpr, javaParser);
//
//                System.out.println("objectCreationExpr: " + objectCreationExpr.toString());
//                System.out.println("objectCreationExpr: " + objectCreationExpr.toString());
//                System.out.println("objectCreationExpr: " + objectCreationExpr.getType().toString());
//            }
//        }, null);

        return objectCreationExprs;
    }
}
