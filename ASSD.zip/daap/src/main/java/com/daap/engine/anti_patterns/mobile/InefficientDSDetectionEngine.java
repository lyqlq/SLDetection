package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.VariableDeclarator;

import java.util.ArrayList;

public class InefficientDSDetectionEngine extends engine{

    public static String smell="IDS";
    public static boolean isMIM=false;

    private static int total = 0;

    public static void detect() {
        init();

        total = 0;
        ASD.writeMessage("IDS:");
        ResultDocument resultDocument = new ResultDocument(Constants.A_INEFFICIENT_DATA_STRUCTURE);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        System.out.println("======================STARTED-------------------");

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            isMIM=false;
            for (VariableDeclarator variableDeclarator : legacyClass.getVariableDeclarators()) {
                isMIM=false;
                if (isHashMap(variableDeclarator)) {
//                    System.out.println("legacyClass: " + legacyClass.getName());
                    total++;
//                    ASD.writeMessage("Class: " + legacyClass.getName());
                    ASD.writeMessage("Class Name: " + legacyClass.getName()
                            + "\nPath: " + legacyClass.getPath() + "\n"
                    );
                    try {
                        isMIM=true;
                        CreateFile.createFile(variableDeclarator.clone().toString(),smell, isSmellNumb +"",isMIM);
                        isSmellNumb++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
//                    Constants.setHmap(legacyClass.getName(),Constants.A_INEFFICIENT_DATA_STRUCTURE);
//                    Helper.writeDoc(table, legacyClass, total);
                    Constants.setHmap(legacyClass.getPath(),Constants.A_INEFFICIENT_DATA_STRUCTURE);
                    boolean exists = true;
                    for (DetectedInstance detectedInstance: detectedInstances){
                        if (detectedInstance.getName().equals(legacyClass.getName())){
                            detectedInstance.increment();
                            exists = false;
                            break;
                        }
                    }
                    if (exists){
                        detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                    }
                }
                if (!isMIM){
                    try {
                        CreateFile.createFile(variableDeclarator.clone().toString(),smell, notSellNumb +"",isMIM);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    notSellNumb++;
                }
            }
        }
        System.out.println("total: " + total);
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();
//        Helper.writeFile(doc, "InefficientDS");
        System.out.println("======================FINISHED-------------------");
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);
    }

    private static boolean isHashMap(VariableDeclarator variableDeclarator) {
        if (variableDeclarator.getType().toString().contains("HashMap")) {
            System.out.println("variableDeclarator: " + variableDeclarator.getType().toString());
        }
        if (variableDeclarator.getType().toString().contains("HashMap") &&
                variableDeclarator.getType().toString().contains("String") &&
                variableDeclarator.getType().toString().contains("Integer")) {

            return true;
        }
        return false;
    }
}
