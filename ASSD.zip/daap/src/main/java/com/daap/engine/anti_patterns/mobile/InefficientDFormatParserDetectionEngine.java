package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.MethodDeclaration;

import java.util.ArrayList;

public class InefficientDFormatParserDetectionEngine extends engine{
    public static String smell="IDFP";
    private static boolean isMIM=false;
    private static int total = 0;

    public static void detect() {
        init();
        ASD.writeMessage("IDFP:");
        ResultDocument resultDocument = new ResultDocument(Constants.A_INEFFICIENT_DATA_FORMAT_PARSER);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        total = 0;
        System.out.println("======================STARTED-------------------");

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            isMIM=false;
            for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
                isMIM=false;
                if (methodDeclaration.toString().contains("DocumentBuilderFactory")
                        || methodDeclaration.toString().contains("DocumentBuilder")
                        || methodDeclaration.toString().contains("NodeList")) {

                    System.out.println("legacyClass: " + legacyClass.getName() + " methodDeclaration: " + methodDeclaration.getNameAsString());
                    total++;

                    ASD.writeMessage("Class Name: " + legacyClass.getName()
                            + "\nPath: " + legacyClass.getPath() + "\n"
                    );
                    try {
                        isMIM=true;
                        CreateFile.createFile(methodDeclaration.clone().toString(),smell, isSmellNumb +"",isMIM);
                        isSmellNumb++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
//                    Constants.setHmap(legacyClass.getName(),Constants.A_INEFFICIENT_DATA_FORMAT_PARSER);
                    Constants.setHmap(legacyClass.getPath(),Constants.A_INEFFICIENT_DATA_FORMAT_PARSER);
//                    Helper.writeDoc(table, legacyClass, total);
                    boolean exists = true;
                    for (DetectedInstance detectedInstance: detectedInstances){
                        if (detectedInstance.getName().equals(legacyClass.getName())){
                            detectedInstance.increment();
                            exists = false;
                            break;
                        }
                    }
                    if (exists){
                        detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                    }
                }
                if (!isMIM){
                    try {
                        CreateFile.createFile(methodDeclaration.clone().toString(),smell, notSellNumb +"",isMIM);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    notSellNumb++;
                }
            }
        }

        System.out.println("total: " + total);
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();
//        Helper.writeFile(doc, "InefficientDFormatParser");
        System.out.println("======================FINISHED-------------------");
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);
    }

}
