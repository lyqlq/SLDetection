package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.MethodDeclaration;

import java.util.ArrayList;


public class DroppedDataDetectionEngine {


    public static void detect() {


        ASD.writeMessage("DD:");
        ResultDocument resultDocument = new ResultDocument(Constants.A_DROPPED_DATA);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        int total = 0;
        System.out.println("======================STARTED-------------------");

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            if (legacyClass.getParentClass() != null && (legacyClass.getParentClass().contains("Activity")
                    || legacyClass.getParentClass().contains("Fragment"))) {
                if (isDroppedDataMethodEsists(legacyClass)) {
                    System.out.println();
                    total++;

//                    ASD.writeMessage("Class: " + legacyClass.getName());
                    ASD.writeMessage("Class Name: " + legacyClass.getName()
                            + "\nPath: " + legacyClass.getPath() + "\n"
                    );
                    System.out.println("legacyClass: " + legacyClass.getName());
//                    Constants.setHmap(legacyClass.getName(),Constants.A_DROPPED_DATA);
                    Constants.setHmap(legacyClass.getPath(),Constants.A_DROPPED_DATA);

//                    Helper.writeDoc(table, legacyClass, total);
                    boolean exists = true;
                    for (DetectedInstance detectedInstance: detectedInstances){
                        if (detectedInstance.getName().equals(legacyClass.getName())){
                            detectedInstance.increment();
                            exists = false;
                            break;
                        }
                    }
                    if (exists){
                        detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                    }
//                    writeDoc(legacyClass, total);
                }
            }
        }

        System.out.println("total: " + total);
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();
//        writeFile();
//        Helper.writeFile(doc, "DroppedData");
        System.out.println("======================FINISHED-------------------");
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);
    }


    private static boolean isDroppedDataMethodEsists(LegacyClass legacyClass) {
        boolean isOnSaveInstanceState = true;
        boolean isOnRestoreInstanceState = true;
        for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
            if (methodDeclaration.getNameAsString().equals("onSaveInstanceState")) {
                isOnSaveInstanceState = false;
                break;
            }
        }
        for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
            if (methodDeclaration.getNameAsString().equals("onRestoreInstanceState")) {
                isOnRestoreInstanceState = false;
                break;
            }
            if(isOnSaveInstanceState && isOnRestoreInstanceState){
                System.out.println("===DDD:===");
                System.out.println(methodDeclaration.clone());
            }
        }

        return isOnSaveInstanceState && isOnRestoreInstanceState;
    }
}
