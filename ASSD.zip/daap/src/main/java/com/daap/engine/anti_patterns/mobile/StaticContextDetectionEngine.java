package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.FieldDeclaration;

import java.util.ArrayList;

/**
 * Created by Azhar on 9/21/2017.
 */
public class StaticContextDetectionEngine extends engine{
    public static String smell="SC";
    private static boolean isMIM=false;

    public static void detect() {
        init();

//        XWPFDocument doc;
//        XWPFTable table;
//        doc = new XWPFDocument();
//        table = doc.createTable();
//        table.getRow(0).getCell(0).setText("Sr. No");
//        table.getRow(0).createCell().setText("Class");
////        table.getRow(0).createCell().setText("Method");
//        table.getRow(0).createCell().setText("Path");

        ASD.writeMessage("SC:");
        ResultDocument resultDocument = new ResultDocument(Constants.A_STATIC_CONTEXT);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        int total = 0;
        System.out.println("======================STARTED-------------------");

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            isMIM=false;
            for (FieldDeclaration fieldDeclaration : legacyClass.getFieldDeclarations()) {
                isMIM=false;
                if (isTypeContext(fieldDeclaration)) {
                    total++;
//                    ASD.writeMessage("Class: " + legacyClass.getName());
                    ASD.writeMessage("Class Name: " + legacyClass.getName()
                            + "\nPath: " + legacyClass.getPath() + "\n"
                    );
                    try {
                        isMIM=true;
                        CreateFile.createFile(fieldDeclaration.clone().toString(),smell, isSmellNumb +"",isMIM);
                        isSmellNumb++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    Constants.setHmap(legacyClass.getPath(),Constants.A_STATIC_CONTEXT);
//                    Helper.writeDoc(table, legacyClass, total);
                    boolean exists = true;
                    for (DetectedInstance detectedInstance: detectedInstances){
                        if (detectedInstance.getName().equals(legacyClass.getName())){
                            detectedInstance.increment();
                            exists = false;
                            break;
                        }
                    }
                    if (exists){
                        detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                    }
                }
                if (!isMIM){
                    try {
                        CreateFile.createFile(fieldDeclaration.clone().toString(),smell, notSellNumb +"",isMIM);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    notSellNumb++;
                }
            }
        }

        System.out.println("total: " + total);
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();
//        Helper.writeFile(doc, "StaticContext");
        System.out.println("======================FINISHED-------------------");
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);
    }

    private static boolean isTypeContext(FieldDeclaration fieldDeclaration) {
        if (fieldDeclaration.isStatic() && fieldDeclaration.getCommonType().toString().equals(Constants.CONTEXT)) {
            return true;
        }
        return false;
    }
}
