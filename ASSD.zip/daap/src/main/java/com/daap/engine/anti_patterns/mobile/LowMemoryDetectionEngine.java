package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.MethodDeclaration;

import java.util.ArrayList;

public class LowMemoryDetectionEngine extends engine{//4 split lowmemory
//LM(Low Memory)：这种异味表示该Android应用源代码中没有重写onLowMemory方法，在Android应用程序代码中应重写onLowMemory方法以优化内存。
//private static final String fileName = "No Low Memory Resolver";
    public static String smell="LM";
    public static boolean isMIM=false;
    public static void detect() {
        init();

//        ASD.clearConsole();
        ResultDocument resultDocument = new ResultDocument(Constants.A_LOW_MEMORY);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();

        int total = 0;
        System.out.println("======================STARTED-------------------");
        ASD.writeMessage("Low Memory:\n");
        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            isMIM=false;
            if (legacyClass.getParentClass() != null && legacyClass.getParentClass().contains("Activity")) {
                isMIM=false;
                if (isLowMemoryMethodEsists(legacyClass)) {
                    total++;
//                    ASD.writeMessage("Class: " + legacyClass.getName());
                    ASD.writeMessage("Class Name: " + legacyClass.getName()
                            + "\nPath: " + legacyClass.getPath() + "\n"
                    );
                    try {
                        isMIM=true;
                        CreateFile.createFile(legacyClass.toString(),smell, isSmellNumb +"",isMIM);
                        isSmellNumb++;

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
//                    Constants.setHmap(legacyClass.getName(),Constants.A_LOW_MEMORY);
//                    Helper.writeDoc(table, legacyClass, total);
                    Constants.setHmap(legacyClass.getPath(),Constants.A_LOW_MEMORY);
                    boolean exists = true;
                    for (DetectedInstance detectedInstance: detectedInstances){
                        if (detectedInstance.getName().equals(legacyClass.getName())){
                            detectedInstance.increment();
                            exists = false;
                            break;
                        }
                    }
                    if (exists){
                        detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                    }

                    System.out.println("legacyClass: " + legacyClass.getName());
                }
            }
            if (!isMIM){
                try {
                    CreateFile.createFile(legacyClass.toString(),smell, notSellNumb +"",isMIM);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                notSellNumb++;
            }
        }

        System.out.println("total: " + total);
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();
//        Helper.writeFile(doc, "LowMemory");
        System.out.println("======================FINISHED-------------------");
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument.getTable(), detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument.getDoc(), "LowMemory");
    }

    private static boolean isLowMemoryMethodEsists(LegacyClass legacyClass) {
        boolean isLowMemoryExists = true;
        for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
            if (methodDeclaration.getNameAsString().equals("onLowMemory")) {
                return false;
            }
        }
        return isLowMemoryExists;
    }
}
